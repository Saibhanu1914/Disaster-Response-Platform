import { cache } from "./cache"

interface SocialMediaPost {
  id: string
  user: string
  content: string
  timestamp: string
  platform: string
  engagement: number
}

export class SocialMediaService {
  // Mock Twitter API - replace with real API when available
  async fetchDisasterPosts(disasterId: string, keywords: string[] = []): Promise<SocialMediaPost[]> {
    const cacheKey = `social_media_${disasterId}_${keywords.join("_")}`

    // Check cache first
    const cached = await cache.get(cacheKey)
    if (cached) {
      console.log("Social media data served from cache")
      return cached
    }

    try {
      // Mock social media posts - replace with real API calls
      const mockPosts: SocialMediaPost[] = [
        {
          id: "1",
          user: "citizen_reporter",
          content: "#floodrelief Urgent: Water rising fast on 5th Avenue. Families trapped on 3rd floor!",
          timestamp: new Date().toISOString(),
          platform: "twitter",
          engagement: 45,
        },
        {
          id: "2",
          user: "emergency_volunteer",
          content: "Setting up food distribution at Central Park. #disasterrelief #NYC",
          timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          platform: "twitter",
          engagement: 23,
        },
        {
          id: "3",
          user: "local_news",
          content: "BREAKING: Emergency shelters opening across Manhattan. List of locations: bit.ly/shelter-list",
          timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
          platform: "twitter",
          engagement: 156,
        },
        {
          id: "4",
          user: "concerned_citizen",
          content: "SOS! Elderly neighbor needs medical attention. Can't reach 911. Location: 42nd & Broadway",
          timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
          platform: "twitter",
          engagement: 78,
        },
      ]

      // Filter posts based on keywords if provided
      const filteredPosts =
        keywords.length > 0
          ? mockPosts.filter((post) =>
              keywords.some((keyword) => post.content.toLowerCase().includes(keyword.toLowerCase())),
            )
          : mockPosts

      // Cache the results
      await cache.set(cacheKey, filteredPosts, 15) // Cache for 15 minutes

      console.log(`Social media monitoring: Found ${filteredPosts.length} posts`)
      return filteredPosts
    } catch (error) {
      console.error("Social media fetch error:", error)
      return []
    }
  }

  async analyzePriority(posts: SocialMediaPost[]): Promise<SocialMediaPost[]> {
    const urgentKeywords = ["urgent", "sos", "emergency", "help", "trapped", "medical"]

    return posts.map((post) => ({
      ...post,
      priority: urgentKeywords.some((keyword) => post.content.toLowerCase().includes(keyword)) ? "high" : "normal",
    })) as any
  }
}

export const socialMediaService = new SocialMediaService()
