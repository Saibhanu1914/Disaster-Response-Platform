import * as cheerio from "cheerio"
import { cache } from "./cache"

interface OfficialUpdate {
  title: string
  content: string
  source: string
  url: string
  timestamp: string
}

export class OfficialUpdatesService {
  async fetchUpdates(disasterId: string): Promise<OfficialUpdate[]> {
    const cacheKey = `official_updates_${disasterId}`

    // Check cache first
    const cached = await cache.get(cacheKey)
    if (cached) {
      console.log("Official updates served from cache")
      return cached
    }

    try {
      // Mock official updates - in real implementation, scrape from FEMA, Red Cross, etc.
      const mockUpdates: OfficialUpdate[] = [
        {
          title: "Emergency Shelter Locations Updated",
          content:
            "New emergency shelters have been opened at Madison Square Garden and Jacob Javits Center. Transportation provided from evacuation zones.",
          source: "NYC Emergency Management",
          url: "https://www1.nyc.gov/site/em/index.page",
          timestamp: new Date().toISOString(),
        },
        {
          title: "Flood Warning Extended Through Weekend",
          content:
            "The National Weather Service has extended the flood warning for Manhattan through Sunday evening. Residents should avoid unnecessary travel.",
          source: "National Weather Service",
          url: "https://weather.gov",
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        },
        {
          title: "Emergency Food Distribution Schedule",
          content:
            "Red Cross will distribute emergency food supplies at the following locations: Central Park (10 AM), Brooklyn Bridge Park (2 PM), Queens Plaza (4 PM).",
          source: "American Red Cross",
          url: "https://redcross.org",
          timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
        },
      ]

      // Cache the results
      await cache.set(cacheKey, mockUpdates, 60) // Cache for 1 hour

      console.log(`Official updates: Found ${mockUpdates.length} updates`)
      return mockUpdates
    } catch (error) {
      console.error("Official updates fetch error:", error)
      return []
    }
  }

  private async scrapeFEMA(): Promise<OfficialUpdate[]> {
    try {
      // Example scraping logic - implement based on actual FEMA structure
      const response = await fetch("https://www.fema.gov/disasters")
      const html = await response.text()
      const $ = cheerio.load(html)

      const updates: OfficialUpdate[] = []

      $(".disaster-item").each((i, element) => {
        const title = $(element).find(".title").text().trim()
        const content = $(element).find(".description").text().trim()
        const url = $(element).find("a").attr("href") || ""

        if (title && content) {
          updates.push({
            title,
            content,
            source: "FEMA",
            url: url.startsWith("http") ? url : `https://www.fema.gov${url}`,
            timestamp: new Date().toISOString(),
          })
        }
      })

      return updates
    } catch (error) {
      console.error("FEMA scraping error:", error)
      return []
    }
  }
}

export const officialUpdatesService = new OfficialUpdatesService()
