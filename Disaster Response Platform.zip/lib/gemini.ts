import { GoogleGenerativeAI } from "@google/generative-ai"

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!)

export class GeminiService {
  private model = genAI.getGenerativeModel({ model: "gemini-pro" })
  private visionModel = genAI.getGenerativeModel({ model: "gemini-pro-vision" })

  async extractLocation(description: string): Promise<string | null> {
    try {
      const prompt = `Extract the location name from the following disaster description. Return only the location name (city, state/country format if possible), or "NONE" if no location is found:

Description: ${description}`

      const result = await this.model.generateContent(prompt)
      const response = await result.response
      const location = response.text().trim()

      return location === "NONE" ? null : location
    } catch (error) {
      console.error("Gemini location extraction error:", error)
      return null
    }
  }

  async verifyImage(imageUrl: string): Promise<{
    isAuthentic: boolean
    confidence: number
    analysis: string
  }> {
    try {
      // For demo purposes, we'll simulate image verification
      // In a real implementation, you'd use Gemini Vision API
      const prompt = `Analyze this disaster-related image for authenticity and context. Provide:
1. Whether the image appears authentic (not manipulated)
2. Confidence level (0-100)
3. Brief analysis of what you see

Image URL: ${imageUrl}`

      // Simulated response for demo
      return {
        isAuthentic: Math.random() > 0.2, // 80% chance of being authentic
        confidence: Math.floor(Math.random() * 30) + 70, // 70-100% confidence
        analysis:
          "Image appears to show genuine disaster conditions with consistent lighting and no obvious signs of manipulation.",
      }
    } catch (error) {
      console.error("Gemini image verification error:", error)
      return {
        isAuthentic: false,
        confidence: 0,
        analysis: "Unable to verify image due to technical error.",
      }
    }
  }
}

export const geminiService = new GeminiService()
