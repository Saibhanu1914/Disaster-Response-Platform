interface GeocodeResult {
  lat: number
  lng: number
  formatted_address: string
}

export class GeocodingService {
  async geocodeLocation(locationName: string): Promise<GeocodeResult | null> {
    try {
      // Using OpenStreetMap Nominatim for free geocoding
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(locationName)}&limit=1`,
        {
          headers: {
            "User-Agent": "DisasterResponsePlatform/1.0",
          },
        },
      )

      if (!response.ok) {
        throw new Error("Geocoding API request failed")
      }

      const data = await response.json()

      if (data.length === 0) {
        return null
      }

      const result = data[0]
      return {
        lat: Number.parseFloat(result.lat),
        lng: Number.parseFloat(result.lon),
        formatted_address: result.display_name,
      }
    } catch (error) {
      console.error("Geocoding error:", error)
      return null
    }
  }
}

export const geocodingService = new GeocodingService()
