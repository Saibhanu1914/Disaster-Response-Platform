// Mock authentication system
export interface User {
  id: string
  username: string
  role: "admin" | "contributor"
}

const mockUsers: User[] = [
  { id: "1", username: "netrunnerX", role: "admin" },
  { id: "2", username: "reliefAdmin", role: "admin" },
  { id: "3", username: "volunteer1", role: "contributor" },
  { id: "4", username: "citizen1", role: "contributor" },
]

export class AuthService {
  static authenticate(username: string): User | null {
    return mockUsers.find((user) => user.username === username) || null
  }

  static authorize(user: User, action: string): boolean {
    if (user.role === "admin") return true

    // Contributors can create reports and view data
    if (user.role === "contributor") {
      return ["create_report", "view_disasters", "view_resources"].includes(action)
    }

    return false
  }
}
