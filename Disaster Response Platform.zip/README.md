# Disaster Response Coordination Platform

A comprehensive backend-heavy MERN stack application for disaster response coordination with real-time data aggregation, AI-powered location extraction, and geospatial queries.

## Features

### Core Functionality
- **Disaster Data Management**: Full CRUD operations with ownership tracking and audit trails
- **Location Extraction & Geocoding**: AI-powered location extraction using Google Gemini API
- **Real-time Social Media Monitoring**: Mock Twitter API integration with priority analysis
- **Geospatial Resource Mapping**: PostGIS-powered location-based queries
- **Official Updates Aggregation**: Web scraping from government/relief websites
- **Image Verification**: AI-powered authenticity checking using Gemini API
- **Real-time Updates**: WebSocket integration for live data streaming

### Technical Implementation
- **Backend**: Next.js API routes with Express-like functionality
- **Database**: Supabase (PostgreSQL) with PostGIS for geospatial operations
- **Caching**: Supabase-based caching system with TTL support
- **Authentication**: Mock authentication system with role-based access
- **Real-time**: Socket.IO for WebSocket connections
- **External APIs**: Google Gemini, OpenStreetMap Nominatim, Mock social media

## API Endpoints

### Disasters
- `GET /api/disasters` - List all disasters with optional filtering
- `POST /api/disasters` - Create new disaster
- `GET /api/disasters/[id]` - Get disaster details
- `PUT /api/disasters/[id]` - Update disaster
- `DELETE /api/disasters/[id]` - Delete disaster (admin only)

### Social Media
- `GET /api/disasters/[id]/social-media` - Get social media posts for disaster

### Resources
- `GET /api/disasters/[id]/resources` - Get resources with geospatial filtering
- `POST /api/disasters/[id]/resources` - Add new resource

### Official Updates
- `GET /api/disasters/[id]/official-updates` - Get official updates

### Verification
- `POST /api/disasters/[id]/verify-image` - Verify image authenticity

### Geocoding
- `POST /api/geocode` - Extract location and convert to coordinates

### Reports
- `POST /api/reports` - Submit new report

## Database Schema

### Tables
- `disasters`: Main disaster records with geospatial location data
- `reports`: User-submitted reports with verification status
- `resources`: Emergency resources with location data
- `cache`: API response caching with TTL

### Geospatial Features
- PostGIS extension enabled
- GIST indexes on geography columns
- Distance-based queries using ST_DWithin
- Coordinate system: WGS84 (SRID 4326)

## Setup Instructions

### Prerequisites
- Node.js 18+
- Supabase account
- Google Gemini API key

### Environment Variables
\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
GEMINI_API_KEY=your_gemini_api_key
\`\`\`

### Installation
1. Clone the repository
2. Install dependencies: `npm install`
3. Set up environment variables
4. Run database setup scripts in Supabase SQL editor
5. Start development server: `npm run dev`

## Usage

### Creating Disasters
1. Fill out the disaster creation form
2. System automatically extracts location using Gemini API
3. Geocodes location to coordinates using OpenStreetMap
4. Stores with geospatial data for proximity queries

### Real-time Monitoring
1. Select a disaster from the list
2. View real-time social media posts
3. Monitor resource availability
4. Track official updates
5. Submit and verify reports

### Geospatial Queries
- Find resources within specified radius
- Location-based disaster filtering
- Distance calculations for emergency response

## AI Integration

### Google Gemini API
- **Location Extraction**: Extracts location names from disaster descriptions
- **Image Verification**: Analyzes images for authenticity and context
- **Content Analysis**: Processes social media content for priority classification

### Caching Strategy
- API responses cached in Supabase with 1-hour TTL
- Geospatial queries optimized with PostGIS indexes
- Real-time data balanced with cache efficiency

## WebSocket Events
- `disaster_updated`: Broadcast disaster changes
- `social_media_updated`: New social media posts
- `resources_updated`: Resource availability changes

## Mock Data
The system includes comprehensive mock data for testing:
- Sample disasters in NYC, LA, and Houston
- Mock social media posts with priority classification
- Emergency resources (shelters, food distribution, services)
- Official updates from various agencies

## Deployment
- Frontend: Vercel (automatic deployment)
- Database: Supabase (managed PostgreSQL)
- WebSocket: Vercel serverless functions with Socket.IO

## Development Notes
This project demonstrates:
- Complex backend architecture with multiple external integrations
- Geospatial data handling and optimization
- Real-time data streaming
- AI-powered content processing
- Scalable caching strategies
- Mock authentication and authorization

Built for rapid development using modern tools and AI assistance for complex backend logic implementation.
