import { type NextRequest, NextResponse } from "next/server"
import { createServerClient, isSupabaseConfigured } from "@/lib/supabase"
import { AuthService } from "@/lib/auth"

// Mock data for when database is not available
const mockDisasters = [
  {
    id: "1",
    title: "NYC Flood Emergency",
    location_name: "Manhattan, NYC",
    description: "Heavy flooding in Manhattan due to storm surge. Multiple streets underwater.",
    tags: ["flood", "urgent", "storm"],
    owner_id: "netrunnerX",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    audit_trail: [{ action: "create", user_id: "netrunnerX", timestamp: new Date().toISOString() }],
    reports: [{ count: 3 }],
    resources: [{ count: 2 }],
  },
  {
    id: "2",
    title: "California Wildfire Alert",
    location_name: "Los Angeles, CA",
    description: "Wildfire spreading rapidly in the hills near Los Angeles. Evacuation orders issued.",
    tags: ["wildfire", "evacuation", "urgent"],
    owner_id: "reliefAdmin",
    created_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    audit_trail: [
      { action: "create", user_id: "reliefAdmin", timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString() },
    ],
    reports: [{ count: 1 }],
    resources: [{ count: 1 }],
  },
  {
    id: "3",
    title: "Texas Hurricane Preparation",
    location_name: "Houston, TX",
    description: "Category 3 hurricane approaching Houston. Residents advised to prepare for impact.",
    tags: ["hurricane", "preparation"],
    owner_id: "netrunnerX",
    created_at: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    audit_trail: [
      { action: "create", user_id: "netrunnerX", timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString() },
    ],
    reports: [{ count: 0 }],
    resources: [{ count: 0 }],
  },
]

export async function GET(request: NextRequest) {
  try {
    console.log("GET /api/disasters - Starting request")

    const { searchParams } = new URL(request.url)
    const tag = searchParams.get("tag")

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      console.log("Supabase not configured, returning mock data")
      let filteredData = mockDisasters

      if (tag) {
        filteredData = mockDisasters.filter((disaster) => disaster.tags.includes(tag))
      }

      return NextResponse.json(filteredData)
    }

    // Try to use Supabase
    const supabase = createServerClient()
    if (!supabase) {
      console.log("Supabase client creation failed, returning mock data")
      return NextResponse.json(mockDisasters)
    }

    console.log("Attempting Supabase query...")

    let query = supabase
      .from("disasters")
      .select(`
        *,
        reports(count),
        resources(count)
      `)
      .order("created_at", { ascending: false })

    // Filter by tag if provided
    if (tag) {
      query = query.contains("tags", [tag])
    }

    const { data, error } = await query

    if (error) {
      console.error("Supabase query error:", error)
      console.log("Falling back to mock data due to database error")
      return NextResponse.json(mockDisasters)
    }

    console.log(`Successfully retrieved ${data?.length || 0} disasters from database`)
    return NextResponse.json(data || [])
  } catch (error) {
    console.error("Disasters GET error:", error)
    console.log("Returning mock data due to unexpected error")

    // Always return mock data as fallback
    return NextResponse.json(mockDisasters)
  }
}

export async function POST(request: NextRequest) {
  try {
    console.log("POST /api/disasters - Starting request")

    const body = await request.json()
    const { title, location_name, description, tags, owner_id } = body

    // Validate required fields
    if (!title || !owner_id) {
      return NextResponse.json({ error: "Title and owner_id are required" }, { status: 400 })
    }

    // Mock authentication
    const user = AuthService.authenticate(owner_id)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Create new disaster object
    const newDisaster = {
      id: Date.now().toString(), // Simple ID for mock mode
      title,
      location_name: location_name || null,
      description: description || null,
      tags: tags || [],
      owner_id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      audit_trail: [
        {
          action: "create",
          user_id: owner_id,
          timestamp: new Date().toISOString(),
        },
      ],
      reports: [{ count: 0 }],
      resources: [{ count: 0 }],
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      console.log("Supabase not configured, returning mock response")
      console.log(`Mock disaster created: ${newDisaster.title} by ${owner_id}`)
      return NextResponse.json(newDisaster, { status: 201 })
    }

    // Try to use Supabase
    const supabase = createServerClient()
    if (!supabase) {
      console.log("Supabase client creation failed, returning mock response")
      return NextResponse.json(newDisaster, { status: 201 })
    }

    const disasterData = {
      title,
      location_name: location_name || null,
      description: description || null,
      tags: tags || [],
      owner_id,
      audit_trail: newDisaster.audit_trail,
    }

    const { data, error } = await supabase.from("disasters").insert(disasterData).select().single()

    if (error) {
      console.error("Database error:", error)
      console.log("Falling back to mock response")
      return NextResponse.json(newDisaster, { status: 201 })
    }

    console.log(`Disaster created in database: ${data.title} by ${owner_id}`)
    return NextResponse.json(data, { status: 201 })
  } catch (error) {
    console.error("Disasters POST error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
