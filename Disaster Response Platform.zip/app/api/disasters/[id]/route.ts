import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { AuthService } from "@/lib/auth"
import { wsManager } from "@/lib/websocket"

const supabase = createServerClient()

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { data, error } = await supabase
      .from("disasters")
      .select(`
        *,
        reports:reports(*),
        resources:resources(*)
      `)
      .eq("id", params.id)
      .single()

    if (error) {
      console.error("Database error:", error)
      return NextResponse.json({ error: "Disaster not found" }, { status: 404 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Disaster GET error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const { title, location_name, description, tags, user_id } = body

    // Mock authentication
    const user = AuthService.authenticate(user_id)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get current disaster to update audit trail
    const { data: currentDisaster } = await supabase
      .from("disasters")
      .select("audit_trail, owner_id")
      .eq("id", params.id)
      .single()

    if (!currentDisaster) {
      return NextResponse.json({ error: "Disaster not found" }, { status: 404 })
    }

    // Check authorization
    if (user.role !== "admin" && currentDisaster.owner_id !== user_id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Update audit trail
    const auditEntry = {
      action: "update",
      user_id,
      timestamp: new Date().toISOString(),
      changes: { title, location_name, description, tags },
    }

    const updatedAuditTrail = [...(currentDisaster.audit_trail || []), auditEntry]

    const { data, error } = await supabase
      .from("disasters")
      .update({
        title,
        location_name,
        description,
        tags: tags || [],
        audit_trail: updatedAuditTrail,
      })
      .eq("id", params.id)
      .select()
      .single()

    if (error) {
      console.error("Database error:", error)
      return NextResponse.json({ error: "Failed to update disaster" }, { status: 500 })
    }

    console.log(`Disaster updated: ${data.title} by ${user_id}`)

    // Emit WebSocket update
    wsManager.emitDisasterUpdate(params.id, {
      type: "updated",
      disaster: data,
    })

    return NextResponse.json(data)
  } catch (error) {
    console.error("Disaster PUT error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { searchParams } = new URL(request.url)
    const user_id = searchParams.get("user_id")

    if (!user_id) {
      return NextResponse.json({ error: "User ID required" }, { status: 400 })
    }

    // Mock authentication
    const user = AuthService.authenticate(user_id)
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { error } = await supabase.from("disasters").delete().eq("id", params.id)

    if (error) {
      console.error("Database error:", error)
      return NextResponse.json({ error: "Failed to delete disaster" }, { status: 500 })
    }

    console.log(`Disaster deleted: ${params.id} by ${user_id}`)

    // Emit WebSocket update
    wsManager.emitDisasterUpdate(params.id, {
      type: "deleted",
      disaster_id: params.id,
    })

    return NextResponse.json({ message: "Disaster deleted successfully" })
  } catch (error) {
    console.error("Disaster DELETE error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
