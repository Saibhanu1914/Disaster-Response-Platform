import { type NextRequest, NextResponse } from "next/server"

// Mock official updates
const mockOfficialUpdates = [
  {
    title: "Emergency Shelter Locations Updated",
    content:
      "New emergency shelters have been opened at Madison Square Garden and Jacob Javits Center. Transportation provided from evacuation zones.",
    source: "NYC Emergency Management",
    url: "https://www1.nyc.gov/site/em/index.page",
    timestamp: new Date().toISOString(),
  },
  {
    title: "Flood Warning Extended Through Weekend",
    content:
      "The National Weather Service has extended the flood warning for Manhattan through Sunday evening. Residents should avoid unnecessary travel.",
    source: "National Weather Service",
    url: "https://weather.gov",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
  {
    title: "Emergency Food Distribution Schedule",
    content:
      "Red Cross will distribute emergency food supplies at the following locations: Central Park (10 AM), Brooklyn Bridge Park (2 PM), Queens Plaza (4 PM).",
    source: "American Red Cross",
    url: "https://redcross.org",
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
  },
]

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    console.log(`GET /api/disasters/${params.id}/official-updates - Starting request`)

    console.log(`Official updates API: Retrieved ${mockOfficialUpdates.length} updates for disaster ${params.id}`)

    return NextResponse.json({
      disaster_id: params.id,
      updates: mockOfficialUpdates,
      total: mockOfficialUpdates.length,
      last_updated: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Official updates API error:", error)
    return NextResponse.json({ error: "Failed to fetch official updates" }, { status: 500 })
  }
}
