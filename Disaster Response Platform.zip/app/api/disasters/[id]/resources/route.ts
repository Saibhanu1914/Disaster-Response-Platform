import { type NextRequest, NextResponse } from "next/server"

// Mock resources data
const mockResources = [
  {
    id: "1",
    disaster_id: "1",
    name: "Red Cross Emergency Shelter",
    location_name: "Lower East Side, NYC",
    type: "shelter",
    created_at: new Date().toISOString(),
  },
  {
    id: "2",
    disaster_id: "1",
    name: "NYC Emergency Food Distribution",
    location_name: "Brooklyn, NYC",
    type: "food",
    created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "3",
    disaster_id: "2",
    name: "LA Fire Department Station 27",
    location_name: "Beverly Hills, CA",
    type: "emergency_services",
    created_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "4",
    disaster_id: "1",
    name: "Manhattan Medical Center",
    location_name: "Midtown, NYC",
    type: "medical",
    created_at: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
  },
]

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    console.log(`GET /api/disasters/${params.id}/resources - Starting request`)

    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type")

    // Filter resources by disaster ID
    let resources = mockResources.filter((resource) => resource.disaster_id === params.id)

    // Filter by resource type if provided
    if (type) {
      resources = resources.filter((resource) => resource.type === type)
    }

    console.log(`Resources API: Retrieved ${resources.length} resources for disaster ${params.id}`)

    return NextResponse.json({
      disaster_id: params.id,
      resources,
      total: resources.length,
      filters: { type },
    })
  } catch (error) {
    console.error("Resources API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    console.log(`POST /api/disasters/${params.id}/resources - Starting request`)

    const body = await request.json()
    const { name, location_name, type } = body

    if (!name || !type) {
      return NextResponse.json({ error: "Name and type are required" }, { status: 400 })
    }

    const newResource = {
      id: Date.now().toString(),
      disaster_id: params.id,
      name,
      location_name: location_name || null,
      type,
      created_at: new Date().toISOString(),
    }

    console.log(`Resource created: ${newResource.name} for disaster ${params.id}`)

    return NextResponse.json(newResource, { status: 201 })
  } catch (error) {
    console.error("Resource POST error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
