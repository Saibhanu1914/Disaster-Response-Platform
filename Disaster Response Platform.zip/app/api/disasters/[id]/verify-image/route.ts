import { type NextRequest, NextResponse } from "next/server"
import { geminiService } from "@/lib/gemini"
import { createServerClient } from "@/lib/supabase"

const supabase = createServerClient()

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const { image_url, report_id } = body

    if (!image_url) {
      return NextResponse.json({ error: "Image URL is required" }, { status: 400 })
    }

    // Verify image using Gemini API
    const verification = await geminiService.verifyImage(image_url)

    // Update report verification status if report_id provided
    if (report_id) {
      const status = verification.isAuthentic && verification.confidence > 70 ? "verified" : "rejected"

      await supabase
        .from("reports")
        .update({ verification_status: status })
        .eq("id", report_id)
        .eq("disaster_id", params.id)
    }

    console.log(
      `Image verification: ${image_url} - ${verification.isAuthentic ? "AUTHENTIC" : "SUSPICIOUS"} (${verification.confidence}% confidence)`,
    )

    return NextResponse.json({
      disaster_id: params.id,
      image_url,
      verification,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Image verification API error:", error)
    return NextResponse.json({ error: "Failed to verify image" }, { status: 500 })
  }
}
