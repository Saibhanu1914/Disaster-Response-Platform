import { NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"

export async function GET() {
  try {
    const supabase = createServerClient()

    // Test database connection
    const { data, error } = await supabase.from("disasters").select("count").limit(1)

    if (error) {
      return NextResponse.json(
        {
          status: "error",
          database: "disconnected",
          error: error.message,
          timestamp: new Date().toISOString(),
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      status: "healthy",
      database: "connected",
      timestamp: new Date().toISOString(),
      environment: {
        supabase_url: process.env.NEXT_PUBLIC_SUPABASE_URL ? "configured" : "missing",
        supabase_key: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? "configured" : "missing",
        service_key: process.env.SUPABASE_SERVICE_ROLE_KEY ? "configured" : "missing",
        gemini_key: process.env.GEMINI_API_KEY ? "configured" : "missing",
      },
    })
  } catch (error) {
    return NextResponse.json(
      {
        status: "error",
        message: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
