import { type NextRequest, NextResponse } from "next/server"
import { AuthService } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    console.log("POST /api/reports - Starting request")

    const body = await request.json()
    const { disaster_id, user_id, content, image_url } = body

    // Validate required fields
    if (!disaster_id || !user_id || !content) {
      return NextResponse.json({ error: "disaster_id, user_id, and content are required" }, { status: 400 })
    }

    // Mock authentication
    const user = AuthService.authenticate(user_id)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const newReport = {
      id: Date.now().toString(),
      disaster_id,
      user_id,
      content,
      image_url: image_url || null,
      verification_status: "pending",
      created_at: new Date().toISOString(),
    }

    console.log(`Report created: ${newReport.id} by ${user_id} for disaster ${disaster_id}`)

    return NextResponse.json(newReport, { status: 201 })
  } catch (error) {
    console.error("Reports POST error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
