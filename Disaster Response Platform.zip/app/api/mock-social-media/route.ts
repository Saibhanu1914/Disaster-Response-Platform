import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const keywords = searchParams.get("keywords")?.split(",") || []
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    // Mock social media posts
    const allPosts = [
      {
        id: "1",
        user: "emergency_alert",
        content: "#FloodAlert Manhattan underwater! Broadway completely flooded. Avoid the area! #NYC #Emergency",
        timestamp: new Date().toISOString(),
        platform: "twitter",
        engagement: 234,
        location: "Manhattan, NYC",
      },
      {
        id: "2",
        user: "citizen_reporter",
        content: "SOS! Trapped in building on 5th Avenue. Water rising fast. Need immediate help! #Emergency #Flood",
        timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        platform: "twitter",
        engagement: 89,
        location: "5th Avenue, NYC",
      },
      {
        id: "3",
        user: "relief_volunteer",
        content:
          "Setting up emergency shelter at Central Park. Hot food and dry clothes available. #DisasterRelief #NYC",
        timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
        platform: "twitter",
        engagement: 156,
        location: "Central Park, NYC",
      },
      {
        id: "4",
        user: "local_news_ny",
        content:
          "BREAKING: Emergency services overwhelmed. If you need urgent help, try alternative routes to hospitals. #NYCFlood",
        timestamp: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
        platform: "twitter",
        engagement: 445,
        location: "New York City",
      },
      {
        id: "5",
        user: "concerned_parent",
        content: "School buses stuck in flood water near Brooklyn Bridge. Kids safe but scared. When will help arrive?",
        timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
        platform: "twitter",
        engagement: 67,
        location: "Brooklyn Bridge, NYC",
      },
    ]

    // Filter by keywords if provided
    let filteredPosts = allPosts
    if (keywords.length > 0) {
      filteredPosts = allPosts.filter((post) =>
        keywords.some(
          (keyword) =>
            post.content.toLowerCase().includes(keyword.toLowerCase()) ||
            post.location.toLowerCase().includes(keyword.toLowerCase()),
        ),
      )
    }

    // Limit results
    const posts = filteredPosts.slice(0, limit)

    return NextResponse.json({
      posts,
      total: posts.length,
      keywords,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Mock social media API error:", error)
    return NextResponse.json({ error: "Failed to fetch social media data" }, { status: 500 })
  }
}
