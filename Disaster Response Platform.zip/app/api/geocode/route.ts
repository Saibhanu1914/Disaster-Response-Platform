import { type NextRequest, NextResponse } from "next/server"

// Mock geocoding results for demo
const mockGeocodingResults: Record<string, any> = {
  manhattan: {
    lat: 40.7831,
    lng: -73.9712,
    formatted_address: "Manhattan, New York, NY, USA",
  },
  "los angeles": {
    lat: 34.0522,
    lng: -118.2437,
    formatted_address: "Los Angeles, CA, USA",
  },
  houston: {
    lat: 29.7604,
    lng: -95.3698,
    formatted_address: "Houston, TX, USA",
  },
}

export async function POST(request: NextRequest) {
  try {
    console.log("POST /api/geocode - Starting request")

    const body = await request.json()
    const { description, location_name } = body

    let locationToGeocode = location_name

    // Simple location extraction from description if no location_name
    if (!locationToGeocode && description) {
      const text = description.toLowerCase()
      if (text.includes("manhattan") || text.includes("nyc")) {
        locationToGeocode = "Manhattan, NYC"
      } else if (text.includes("los angeles") || text.includes("la")) {
        locationToGeocode = "Los Angeles, CA"
      } else if (text.includes("houston")) {
        locationToGeocode = "Houston, TX"
      }
    }

    if (!locationToGeocode) {
      return NextResponse.json({ error: "No location found to geocode" }, { status: 400 })
    }

    // Mock geocoding
    const searchKey = locationToGeocode.toLowerCase()
    let geocodeResult = null

    for (const [key, result] of Object.entries(mockGeocodingResults)) {
      if (searchKey.includes(key)) {
        geocodeResult = result
        break
      }
    }

    if (!geocodeResult) {
      // Default result for unknown locations
      geocodeResult = {
        lat: 40.7128,
        lng: -74.006,
        formatted_address: locationToGeocode,
      }
    }

    console.log(`Geocoding: "${locationToGeocode}" -> ${geocodeResult.lat}, ${geocodeResult.lng}`)

    return NextResponse.json({
      input: {
        description,
        location_name,
      },
      extracted_location: locationToGeocode,
      geocode_result: geocodeResult,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Geocoding API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
