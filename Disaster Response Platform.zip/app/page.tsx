"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Clock, Users, AlertTriangle, Radio, Shield, Globe } from "lucide-react"
import { io, type Socket } from "socket.io-client"

interface Disaster {
  id: string
  title: string
  location_name: string
  description: string
  tags: string[]
  owner_id: string
  created_at: string
  reports?: { count: number }[]
  resources?: { count: number }[]
}

interface SocialMediaPost {
  id: string
  user: string
  content: string
  timestamp: string
  platform: string
  engagement: number
  priority?: string
}

interface Resource {
  id: string
  name: string
  location_name: string
  type: string
  created_at: string
}

interface OfficialUpdate {
  title: string
  content: string
  source: string
  url: string
  timestamp: string
}

export default function DisasterResponsePlatform() {
  const [disasters, setDisasters] = useState<Disaster[]>([])
  const [selectedDisaster, setSelectedDisaster] = useState<Disaster | null>(null)
  const [socialMediaPosts, setSocialMediaPosts] = useState<SocialMediaPost[]>([])
  const [resources, setResources] = useState<Resource[]>([])
  const [officialUpdates, setOfficialUpdates] = useState<OfficialUpdate[]>([])
  const [loading, setLoading] = useState(false)
  const [socket, setSocket] = useState<Socket | null>(null)
  const [currentUser] = useState("netrunnerX") // Mock current user

  // Form states
  const [newDisaster, setNewDisaster] = useState({
    title: "",
    location_name: "",
    description: "",
    tags: "",
  })
  const [newReport, setNewReport] = useState({
    content: "",
    image_url: "",
  })

  // Initialize WebSocket connection
  useEffect(() => {
    const socketConnection = io()
    setSocket(socketConnection)

    socketConnection.on("disaster_updated", (data) => {
      console.log("Received disaster update:", data)
      fetchDisasters() // Refresh disasters list
    })

    socketConnection.on("social_media_updated", (data) => {
      console.log("Received social media update:", data)
      if (data.posts) {
        setSocialMediaPosts(data.posts)
      }
    })

    socketConnection.on("resources_updated", (data) => {
      console.log("Received resources update:", data)
      if (selectedDisaster) {
        fetchResources(selectedDisaster.id)
      }
    })

    return () => {
      socketConnection.disconnect()
    }
  }, [selectedDisaster])

  // Fetch disasters on component mount
  useEffect(() => {
    fetchDisasters()
  }, [])

  const fetchDisasters = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/disasters")

      if (!response.ok) {
        const errorText = await response.text()
        console.error("API Error:", response.status, errorText)
        throw new Error(`HTTP ${response.status}: ${errorText}`)
      }

      const data = await response.json()
      setDisasters(data)
    } catch (error) {
      console.error("Error fetching disasters:", error)
      // Set empty array as fallback
      setDisasters([])
    } finally {
      setLoading(false)
    }
  }

  const fetchSocialMedia = async (disasterId: string) => {
    try {
      const response = await fetch(`/api/disasters/${disasterId}/social-media?keywords=flood,emergency,urgent`)
      const data = await response.json()
      setSocialMediaPosts(data.posts || [])
    } catch (error) {
      console.error("Error fetching social media:", error)
    }
  }

  const fetchResources = async (disasterId: string) => {
    try {
      const response = await fetch(`/api/disasters/${disasterId}/resources`)
      const data = await response.json()
      setResources(data.resources || [])
    } catch (error) {
      console.error("Error fetching resources:", error)
    }
  }

  const fetchOfficialUpdates = async (disasterId: string) => {
    try {
      const response = await fetch(`/api/disasters/${disasterId}/official-updates`)
      const data = await response.json()
      setOfficialUpdates(data.updates || [])
    } catch (error) {
      console.error("Error fetching official updates:", error)
    }
  }

  const createDisaster = async () => {
    try {
      const response = await fetch("/api/disasters", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...newDisaster,
          tags: newDisaster.tags
            .split(",")
            .map((tag) => tag.trim())
            .filter(Boolean),
          owner_id: currentUser,
        }),
      })

      if (response.ok) {
        setNewDisaster({ title: "", location_name: "", description: "", tags: "" })
        fetchDisasters()
      }
    } catch (error) {
      console.error("Error creating disaster:", error)
    }
  }

  const createReport = async () => {
    if (!selectedDisaster) return

    try {
      const response = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...newReport,
          disaster_id: selectedDisaster.id,
          user_id: currentUser,
        }),
      })

      if (response.ok) {
        setNewReport({ content: "", image_url: "" })
        // Refresh disaster details
        const updatedDisaster = disasters.find((d) => d.id === selectedDisaster.id)
        if (updatedDisaster) {
          setSelectedDisaster(updatedDisaster)
        }
      }
    } catch (error) {
      console.error("Error creating report:", error)
    }
  }

  const selectDisaster = (disaster: Disaster) => {
    setSelectedDisaster(disaster)

    // Join disaster room for real-time updates
    if (socket) {
      socket.emit("join_disaster", disaster.id)
    }

    // Fetch related data
    fetchSocialMedia(disaster.id)
    fetchResources(disaster.id)
    fetchOfficialUpdates(disaster.id)
  }

  const geocodeLocation = async (description: string, locationName?: string) => {
    try {
      const response = await fetch("/api/geocode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ description, location_name: locationName }),
      })
      const data = await response.json()
      console.log("Geocoding result:", data)
      return data
    } catch (error) {
      console.error("Error geocoding:", error)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Disaster Response Coordination Platform</h1>
          <p className="text-gray-600">
            Real-time disaster management with AI-powered location extraction and social media monitoring
          </p>
          <div className="mt-4 flex items-center gap-4 text-sm text-gray-500">
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              Current User: {currentUser}
            </span>
            <span className="flex items-center gap-1">
              <Radio className="w-4 h-4" />
              {socket?.connected ? "Connected" : "Disconnected"}
            </span>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Disasters List & Create Form */}
          <div className="lg:col-span-1 space-y-6">
            {/* Create Disaster Form */}
            <Card>
              <CardHeader>
                <CardTitle>Create New Disaster</CardTitle>
                <CardDescription>Add a new disaster event to coordinate response efforts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Disaster title"
                  value={newDisaster.title}
                  onChange={(e) => setNewDisaster({ ...newDisaster, title: e.target.value })}
                />
                <Input
                  placeholder="Location (e.g., Manhattan, NYC)"
                  value={newDisaster.location_name}
                  onChange={(e) => setNewDisaster({ ...newDisaster, location_name: e.target.value })}
                />
                <Textarea
                  placeholder="Description of the disaster"
                  value={newDisaster.description}
                  onChange={(e) => setNewDisaster({ ...newDisaster, description: e.target.value })}
                />
                <Input
                  placeholder="Tags (comma-separated: flood, urgent, storm)"
                  value={newDisaster.tags}
                  onChange={(e) => setNewDisaster({ ...newDisaster, tags: e.target.value })}
                />
                <div className="flex gap-2">
                  <Button onClick={createDisaster} className="flex-1">
                    Create Disaster
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => geocodeLocation(newDisaster.description, newDisaster.location_name)}
                  >
                    Test Geocoding
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Disasters List */}
            <Card>
              <CardHeader>
                <CardTitle>Active Disasters</CardTitle>
                <CardDescription>{disasters.length} active disaster events</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-4">Loading disasters...</div>
                ) : (
                  <div className="space-y-3">
                    {disasters.map((disaster) => (
                      <div
                        key={disaster.id}
                        className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                          selectedDisaster?.id === disaster.id
                            ? "border-blue-500 bg-blue-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                        onClick={() => selectDisaster(disaster)}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-semibold text-sm">{disaster.title}</h3>
                            <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
                              <MapPin className="w-3 h-3" />
                              {disaster.location_name || "Location TBD"}
                            </div>
                            <div className="flex items-center gap-1 text-xs text-gray-500">
                              <Clock className="w-3 h-3" />
                              {new Date(disaster.created_at).toLocaleDateString()}
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            {disaster.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Disaster Details */}
          <div className="lg:col-span-2">
            {selectedDisaster ? (
              <div className="space-y-6">
                {/* Disaster Header */}
                <Card>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <AlertTriangle className="w-5 h-5 text-red-500" />
                          {selectedDisaster.title}
                        </CardTitle>
                        <CardDescription className="mt-2">{selectedDisaster.description}</CardDescription>
                        <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            {selectedDisaster.location_name || "Location TBD"}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {new Date(selectedDisaster.created_at).toLocaleString()}
                          </span>
                          <span>Owner: {selectedDisaster.owner_id}</span>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedDisaster.tags.map((tag) => (
                          <Badge key={tag} variant="outline">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardHeader>
                </Card>

                {/* Tabs for different data sources */}
                <Tabs defaultValue="social-media" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="social-media">Social Media</TabsTrigger>
                    <TabsTrigger value="resources">Resources</TabsTrigger>
                    <TabsTrigger value="official">Official Updates</TabsTrigger>
                    <TabsTrigger value="reports">Reports</TabsTrigger>
                  </TabsList>

                  <TabsContent value="social-media" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Radio className="w-5 h-5" />
                          Social Media Monitoring
                        </CardTitle>
                        <CardDescription>Real-time social media posts related to this disaster</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {socialMediaPosts.map((post) => (
                            <div key={post.id} className="border rounded-lg p-3">
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-2">
                                    <span className="font-semibold text-sm">@{post.user}</span>
                                    <Badge variant="outline" className="text-xs">
                                      {post.platform}
                                    </Badge>
                                    {(post as any).priority === "high" && (
                                      <Badge variant="destructive" className="text-xs">
                                        HIGH PRIORITY
                                      </Badge>
                                    )}
                                  </div>
                                  <p className="text-sm">{post.content}</p>
                                  <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                                    <span>{post.engagement} interactions</span>
                                    <span>{new Date(post.timestamp).toLocaleTimeString()}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                          {socialMediaPosts.length === 0 && (
                            <div className="text-center py-8 text-gray-500">
                              No social media posts found for this disaster
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="resources" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <MapPin className="w-5 h-5" />
                          Available Resources
                        </CardTitle>
                        <CardDescription>Emergency resources and facilities near the disaster area</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {resources.map((resource) => (
                            <div key={resource.id} className="border rounded-lg p-3">
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <h4 className="font-semibold text-sm">{resource.name}</h4>
                                  <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
                                    <MapPin className="w-3 h-3" />
                                    {resource.location_name}
                                  </div>
                                  <div className="flex items-center gap-1 text-xs text-gray-500">
                                    <Clock className="w-3 h-3" />
                                    Added {new Date(resource.created_at).toLocaleDateString()}
                                  </div>
                                </div>
                                <Badge variant="outline" className="text-xs">
                                  {resource.type}
                                </Badge>
                              </div>
                            </div>
                          ))}
                          {resources.length === 0 && (
                            <div className="text-center py-8 text-gray-500">No resources found for this disaster</div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="official" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Globe className="w-5 h-5" />
                          Official Updates
                        </CardTitle>
                        <CardDescription>Updates from government agencies and relief organizations</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {officialUpdates.map((update, index) => (
                            <div key={index} className="border rounded-lg p-4">
                              <div className="flex items-start justify-between mb-2">
                                <h4 className="font-semibold text-sm">{update.title}</h4>
                                <Badge variant="outline" className="text-xs">
                                  {update.source}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-700 mb-2">{update.content}</p>
                              <div className="flex items-center justify-between text-xs text-gray-500">
                                <span>{new Date(update.timestamp).toLocaleString()}</span>
                                <a
                                  href={update.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-blue-600 hover:underline"
                                >
                                  View Source
                                </a>
                              </div>
                            </div>
                          ))}
                          {officialUpdates.length === 0 && (
                            <div className="text-center py-8 text-gray-500">
                              No official updates available for this disaster
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="reports" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Shield className="w-5 h-5" />
                          Submit Report
                        </CardTitle>
                        <CardDescription>Report conditions or needs related to this disaster</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <Textarea
                          placeholder="Describe the situation, needs, or observations..."
                          value={newReport.content}
                          onChange={(e) => setNewReport({ ...newReport, content: e.target.value })}
                        />
                        <Input
                          placeholder="Image URL (optional)"
                          value={newReport.image_url}
                          onChange={(e) => setNewReport({ ...newReport, image_url: e.target.value })}
                        />
                        <Button onClick={createReport} className="w-full">
                          Submit Report
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Display existing reports would go here */}
                    <Card>
                      <CardHeader>
                        <CardTitle>Recent Reports</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-center py-8 text-gray-500">
                          Reports will be displayed here after submission
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <AlertTriangle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Select a Disaster</h3>
                    <p className="text-gray-500">
                      Choose a disaster from the list to view details, social media monitoring, resources, and official
                      updates.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Status Bar */}
        <div className="mt-8 p-4 bg-white rounded-lg border">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <div className={`w-2 h-2 rounded-full ${socket?.connected ? "bg-green-500" : "bg-red-500"}`} />
                WebSocket: {socket?.connected ? "Connected" : "Disconnected"}
              </span>
              <span>Total Disasters: {disasters.length}</span>
              {selectedDisaster && (
                <>
                  <span>Social Media Posts: {socialMediaPosts.length}</span>
                  <span>Resources: {resources.length}</span>
                  <span>Official Updates: {officialUpdates.length}</span>
                </>
              )}
            </div>
            <div className="text-gray-500">Last Updated: {new Date().toLocaleTimeString()}</div>
          </div>
        </div>
      </div>
    </div>
  )
}
