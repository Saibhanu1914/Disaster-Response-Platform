-- Create RPC functions for geospatial queries

-- Function to find disasters within radius
CREATE OR REPLACE FUNCTION disasters_within_radius(
  center_lat FLOAT,
  center_lng FLOAT,
  radius_meters INT DEFAULT 10000
)
RETURNS TABLE (
  id UUID,
  title TEXT,
  location_name TEXT,
  location GEOGRAPHY,
  description TEXT,
  tags TEXT[],
  owner_id TEXT,
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ,
  audit_trail JSONB,
  distance_meters FLOAT
) 
LANGUAGE SQL
AS $$
  SELECT 
    d.*,
    ST_Distance(
      d.location,
      ST_SetSRID(ST_Point(center_lng, center_lat), 4326)
    ) as distance_meters
  FROM disasters d
  WHERE d.location IS NOT NULL
    AND ST_DWithin(
      d.location,
      ST_SetSRID(ST_Point(center_lng, center_lat), 4326),
      radius_meters
    )
  ORDER BY distance_meters;
$$;

-- Function to find resources within radius
CREATE OR REPLACE FUNCTION resources_within_radius(
  disaster_id UUID,
  center_lat FLOAT,
  center_lng FLOAT,
  radius_meters INT DEFAULT 10000
)
RETURNS TABLE (
  id UUID,
  disaster_id UUID,
  name TEXT,
  location_name TEXT,
  location GEOGRAPHY,
  type TEXT,
  created_at TIMESTAMPTZ,
  distance_meters FLOAT
) 
LANGUAGE SQL
AS $$
  SELECT 
    r.*,
    ST_Distance(
      r.location,
      ST_SetSRID(ST_Point(center_lng, center_lat), 4326)
    ) as distance_meters
  FROM resources r
  WHERE r.disaster_id = resources_within_radius.disaster_id
    AND r.location IS NOT NULL
    AND ST_DWithin(
      r.location,
      ST_SetSRID(ST_Point(center_lng, center_lat), 4326),
      radius_meters
    )
  ORDER BY distance_meters;
$$;

-- Function to get nearby resources for any location
CREATE OR REPLACE FUNCTION nearby_resources(
  center_lat FLOAT,
  center_lng FLOAT,
  radius_meters INT DEFAULT 10000,
  resource_type TEXT DEFAULT NULL
)
RETURNS TABLE (
  id UUID,
  disaster_id UUID,
  name TEXT,
  location_name TEXT,
  location GEOGRAPHY,
  type TEXT,
  created_at TIMESTAMPTZ,
  distance_meters FLOAT
) 
LANGUAGE SQL
AS $$
  SELECT 
    r.*,
    ST_Distance(
      r.location,
      ST_SetSRID(ST_Point(center_lng, center_lat), 4326)
    ) as distance_meters
  FROM resources r
  WHERE r.location IS NOT NULL
    AND ST_DWithin(
      r.location,
      ST_SetSRID(ST_Point(center_lng, center_lat), 4326),
      radius_meters
    )
    AND (resource_type IS NULL OR r.type = resource_type)
  ORDER BY distance_meters;
$$;
